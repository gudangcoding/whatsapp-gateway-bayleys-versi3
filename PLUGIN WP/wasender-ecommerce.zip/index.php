<?php

/*
Plugin Name: mpedia-Wacommerce
Plugin URI: https://wa.me/6282298859671
Description: mpedia Wacommerce beta version
Version: 1.1
Author: https://wa.me/628229885967
Author URI: https://wa.me/628229885967
*/

include('fungsi.php');

if (in_array(
  'woocommerce/woocommerce.php',
  apply_filters('active_plugins', get_option('active_plugins'))
)) {
  add_action('admin_menu', 'mpedia_wacommerce_menu');


  add_action('init', 'mpedia_wacommerce_check_update');

  // function mpedia_wacommerce_check_update()
  // {
  //   global $wp_version;
  //   global $pagenow;

  //   $plugin_name = "mpedia_wacommerce";
  //   $this_file = __FILE__;

  //   if (is_admin() and $pagenow == "plugins.php") {
  //     if (!function_exists('get_plugin_data')) {
  //       require_once(ABSPATH . 'wp-admin/includes/plugin.php');
  //     }
  //     $plugin_data = get_plugin_data(__FILE__);
  //     $version = $plugin_data['Version'];

  //     $plugin_folder = plugin_basename(dirname($this_file));
  //     $plugin_file = basename(($this_file));

  //     $response   = wp_remote_get("https://mpedia.com/plugin/update.php");

  //     if (!is_array($response) && empty($response['body'])) {
  //       return false;
  //     }

  //     $parse    = json_decode($response['body'], true);

  //     if (!isset($parse[$plugin_name])) {
  //       return;
  //     }

  //     $updateData = $parse[$plugin_name];

  //     if (isset($updateData['Version']) and isset($updateData['Package'])) {
  //       $new_version   = $updateData['Version'];
  //       $package    = $updateData['Package'];

  //       if ($version == $new_version) {
  //         return;
  //       }

  //       $plugin_transient = get_site_transient('update_plugins');
  //       $a = array(
  //         'slug' => $plugin_folder,
  //         'new_version' => $new_version,
  //         'url' => $package,
  //         'package' => $package
  //       );

  //       $o = (object) $a;
  //       $plugin_transient->response[$plugin_folder . '/' . $plugin_file] = $o;
  //       set_site_transient('update_plugins', $plugin_transient);
  //     }
  //   }
  // }
}
