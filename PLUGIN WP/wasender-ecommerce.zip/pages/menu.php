<html lang="en">

<head>

    <meta charset="UTF-8">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">

    <script>
        window.console = window.console || function(t) {};
    </script>



    <script>
        if (document.location.search.match(/type=embed/gi)) {
            window.parent.postMessage("resize", "*");
        }
    </script>


</head>

<body translate="no">
    <!--**************************-->
    <div class="container mr-10">
        <div class="row">
            <div class="col-md-12">
                <h1><span class="glyphicon glyphicon-edit"></span> wacommerce Settings
                </h1>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 bhoechie-tab-container">
                <div class="col-xs-12 col-sm-1 col-md-1 bhoechie-tab-menu">
                    <div class="list-group">
                        <a href="#" class="list-group-item text-center active">
                            <i class="fa fa-gear"></i><br><span class="tab-name">Plugin</span>
                        </a>
                        <a href="#" class="list-group-item text-center">
                            <i class="fa fa-envelope"></i><br><span class="tab-name">Pesan</span>
                        </a>
                        <a href="#" class="list-group-item text-center">
                            <i class="fa fa-send"></i><br><span class="tab-name">Resi</span>
                        </a>
                        <a href="#" class="list-group-item text-center">
                            <i class="fa fa-book"></i><br><span class="tab-name">Cron Job</span>
                        </a>
                        <!--                         <a href="#" class="list-group-item text-center">
                            <i class="fa fa-book"></i><br><span class="tab-name">Payment Gateway</span>
                        </a> -->
                    </div>
                </div>
                <div class="col-xs-12 col-sm-11 col-md-11 bhoechie-tab">
                    <!-- flight section -->
                    <div class="bhoechie-tab-content active">
                        <form enctype="multipart/form-data" class="form-broadcast-wa" method="POST">
                            <input type="hidden" name="mpedia_wacommerce_form_setting" value="" />
                            <table>
                                <tr>
                                    <td>Link</td>
                                    <td><input type="text" name="mpedia_wacommerce_link" value="<?php echo get_option('mpedia_wacommerce_link'); ?>" required /></td>
                                </tr>
                                <tr>
                                    <td>Api Key</td>
                                    <td><input type="text" name="mpedia_wacommerce_token_wa" value="<?php echo str_repeat("*", strlen(get_option('mpedia_wacommerce_token_wa'))); ?>" required /></td>
                                </tr>
                                <tr>
                                    <td>Nomer Admin</td>
                                    <td><input type="text" name="mpedia_wacommerce_nomer_admin" value="<?php echo get_option('mpedia_wacommerce_nomer_admin'); ?>" required /></td>
                                </tr>
                                <tr>
                                    <td>Status Plugin</td>
                                    <td><select name="mpedia_wacommerce_status_plugin">
                                            <option value="off" <?php echo ((get_option('mpedia_wacommerce_status_plugin')) ? ((get_option('mpedia_wacommerce_status_plugin') == "off") ? 'selected' : '') : ''); ?>>Tidak Aktif</option>
                                            <option value="on" <?php echo ((get_option('mpedia_wacommerce_status_plugin')) ? ((get_option('mpedia_wacommerce_status_plugin') == "on") ? 'selected' : '') : ''); ?>>Aktif</option>
                                        </select></td>
                                </tr>
                                <tr>
                                    <td>Notif Order</td>
                                    <td><select name="mpedia_wacommerce_status_notif_order">
                                            <option value="off" <?php echo ((get_option('mpedia_wacommerce_status_notif_order')) ? ((get_option('mpedia_wacommerce_status_notif_order') == "off") ? 'selected' : '') : ''); ?>>Tidak Aktif</option>
                                            <option value="on" <?php echo ((get_option('mpedia_wacommerce_status_notif_order')) ? ((get_option('mpedia_wacommerce_status_notif_order') == "on") ? 'selected' : '') : ''); ?>>Aktif</option>
                                        </select></td>
                                </tr>
                                <tr>
                                    <td>Notif H+ Belum Bayar</td>
                                    <td><select name="mpedia_wacommerce_status_cron_pending">
                                            <option value="off" <?php echo ((get_option('mpedia_wacommerce_status_cron_pending')) ? ((get_option('mpedia_wacommerce_status_cron_pending') == "off") ? 'selected' : '') : ''); ?>>Tidak Aktif</option>
                                            <option value="on" <?php echo ((get_option('mpedia_wacommerce_status_cron_pending')) ? ((get_option('mpedia_wacommerce_status_cron_pending') == "on") ? 'selected' : '') : ''); ?>>Aktif</option>
                                        </select></td>
                                </tr>
                                <tr>
                                    <td>Notif H+x belum bayar</td>
                                    <td><input type="number" name="mpedia_wacommerce_cron_pending" value="<?php echo get_option('mpedia_wacommerce_cron_pending'); ?>" /></td>
                                </tr>
                                <tr>
                                    <td colspan="2"><input type="submit" value="Simpan" /></td>
                                </tr>
                            </table>
                        </form>
                    </div>

                    <div class="bhoechie-tab-content">
                        <form enctype="multipart/form-data" class="form-broadcast-wa" method="POST">
                            <input type="hidden" name="mpedia_wacommerce_setting_pesan" value="" />
                            <table>
                                <tr>
                                    <td>Pesan Order</td>
                                    <td>
                                        <textarea cols="50" rows="7" name="mpedia_wacommerce_pesan_order"><?= get_option('mpedia_wacommerce_pesan_order'); ?></textarea>
                                    </td>
                                    <td><span>Keyword tersedia :<br>
                                            {detail} berisi data produk yang dibeli<br>
                                            {pembayaran} berisi data rekening pembayaran *hanya untuk bank transfer<br>
                                            {nama} Nama Pembeli<br>
                                            {order_id} Order ID<br>
                                            {total} Total pembayaran<br>
                                            {tanggal} Tanggal Pembelian<br>
                                            {payment} Pembayaran yang dipilih
                                        </span></td>
                                </tr>
                                <tr>
                                    <td>Pesan Notif H+ blum bayar</td>
                                    <td>
                                        <textarea cols="50" rows="7" name="mpedia_wacommerce_pesan_notif_blum_bayar"><?= get_option('mpedia_wacommerce_pesan_notif_blum_bayar'); ?></textarea>
                                    </td>
                                    <td><span>Keyword tersedia :<br>
                                            {detail} berisi data produk yang dibeli<br>
                                            {pembayaran} berisi data rekening pembayaran *hanya untuk bank transfer<br>
                                            {nama} Nama Pembeli<br>
                                            {order_id} Order ID<br>
                                            {total} Total pembayaran<br>
                                            {tanggal} Tanggal Pembelian<br>
                                        </span></td>
                                </tr>
                                <tr>
                                    <td>Pesan Kirim Resi</td>
                                    <td>
                                        <textarea cols="50" rows="7" name="mpedia_wacommerce_pesan_kirim_resi"><?= get_option('mpedia_wacommerce_pesan_kirim_resi'); ?></textarea>
                                    </td>
                                    <td><span>Keyword tersedia :<br>
                                            {nama} Nama Pembeli<br>
                                            {order_id} Order ID<br>
                                            {resi} Nomer Resi<br>
                                        </span></td>
                                </tr>
                                <tr>
                                    <td>Pesan Completed</td>
                                    <td>
                                        <textarea cols="50" rows="7" name="mpedia_wacommerce_pesan_completed"><?= get_option("mpedia_wacommerce_pesan_completed"); ?></textarea>
                                    </td>
                                    <td><span>Keyword tersedia :<br>
                                            {nama} Nama Pembeli<br>
                                            {order_id} Order ID<br>
                                        </span></td>
                                </tr>
                                <tr>
                                    <td>Pesan Processing</td>
                                    <td>
                                        <textarea cols="50" rows="7" name="mpedia_wacommerce_pesan_processing"><?= get_option("mpedia_wacommerce_pesan_processing"); ?></textarea>
                                    </td>
                                    <td><span>Keyword tersedia :<br>
                                            {nama} Nama Pembeli<br>
                                            {order_id} Order ID<br>
                                        </span></td>
                                </tr>
                                <tr>
                                    <td>Pesan Pending</td>
                                    <td>
                                        <textarea cols="50" rows="7" name="mpedia_wacommerce_pesan_pending"><?= get_option("mpedia_wacommerce_pesan_pending"); ?></textarea>
                                    </td>
                                    <td><span>Keyword tersedia :<br>
                                            {nama} Nama Pembeli<br>
                                            {order_id} Order ID<br>
                                        </span></td>
                                </tr>
                                <tr>
                                    <td>Pesan Cancelled</td>
                                    <td>
                                        <textarea cols="50" rows="7" name="mpedia_wacommerce_pesan_cancelled"><?= get_option("mpedia_wacommerce_pesan_cancelled"); ?></textarea>
                                    </td>
                                    <td><span>Keyword tersedia :<br>
                                            {nama} Nama Pembeli<br>
                                            {order_id} Order ID<br>
                                        </span></td>
                                </tr>
                                <tr>
                                    <td>Pesan Refunded</td>
                                    <td>
                                        <textarea cols="50" rows="7" name="mpedia_wacommerce_pesan_refunded"><?= get_option("mpedia_wacommerce_pesan_refunded"); ?></textarea>
                                    </td>
                                    <td><span>Keyword tersedia :<br>
                                            {nama} Nama Pembeli<br>
                                            {order_id} Order ID<br>
                                        </span></td>
                                </tr>
                                <tr>
                                    <td>Pesan Failed</td>
                                    <td>
                                        <textarea cols="50" rows="7" name="mpedia_wacommerce_pesan_failed"><?= get_option("mpedia_wacommerce_pesan_failed"); ?></textarea>
                                    </td>
                                    <td><span>Keyword tersedia :<br>
                                            {nama} Nama Pembeli<br>
                                            {order_id} Order ID<br>
                                        </span></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><input type="submit" value="Simpan" /></td>
                                </tr>
                            </table>
                        </form>
                    </div>
                    <?php
                    $orderan = $wpdb->get_results("select * from " . $wpdb->prefix . "wc_order_stats as a inner join " . $wpdb->prefix . "wc_customer_lookup as b on a.customer_id = b.customer_id order by a.order_id desc");
                    foreach ($orderan as $order) {
                        $noresi = get_post_meta($order->order_id, 'mpedia_wacommerce_resi', true);
                        $fullname = $order->first_name . (($order->last_name != "") ? " " . $order->last_name : "");
                        $list[] = '<option value="' . $order->order_id . '">#' . $order->order_id . ' - ' . $fullname . ' ( Rp ' . number_format($order->net_total, 0, ',', '.') . ' ) - ' . str_replace("-", " ", str_replace("wc-", "", $order->status)) . ' - Resi : ' . (($noresi) ? $noresi : null) . '</option>';
                    }
                    ?>
                    <div class="bhoechie-tab-content">
                        <form enctype="multipart/form-data" class="form-broadcast-wa" method="POST">
                            <input type="hidden" name="mpedia_wacommerce_input_resi" value="" />
                            <table>
                                <tr>
                                    <td>Status</td>
                                    <td><select name="mpedia_wacommerce_orderan">
                                            <?php echo implode("", $list); ?>
                                        </select></td>
                                </tr>
                                <tr>
                                    <td>Input Resi</td>
                                    <td><input type="text" name="mpedia_wacommerce_nomer_resi" required /></td>
                                </tr>
                                <tr>
                                    <td colspan="2"><input type="submit" value="Kirim" /></td>
                                </tr>
                            </table>
                        </form>
                    </div>

                    <div class="bhoechie-tab-content">
                        <h2>Setting Cronjob</h2>
                        <p>Pastikan kamu sudah disable wp cron, caranya :</p>
                        <p>1. Buka file wp-config.php</p>
                        <p>2. Tambahkan define( 'DISABLE_WP_CRON', true); diatas tulisan “That’s all, stop editing! Happy blogging.”</p>
                        <p>3. Save</p>
                        <p>Tambahkan cronjob ke url : <?php echo get_rest_url(null, 'wacommerce/cronjob'); ?></p>
                        <p>Setting 6 jam sekali atau 1 hari sekali</p>
                        <p>Jika kamu menggunakan hosting, masuk ke menu cron jobs masukkan command :</p>
                        <p>curl --request GET '<?php echo get_rest_url(null, 'wacommerce/cronjob'); ?>'</p>
                        <p>Setting setiap 6 jam sekali atau 1 hari sekali</p>
                    </div>

                    <div class="bhoechie-tab-content">
                        <form enctype="multipart/form-data" class="form-broadcast-wa" method="POST">
                            <input type="hidden" name="mpedia_wacommerce_payment_setting" value="" />
                            <table>
                                <tr>
                                    <td>Url Endpoint</td>
                                    <td><input type="text" value="<?php echo ((get_option('mpedia_wacommerce_endpoint') != null) ? get_rest_url(null, 'wacommerce/' . get_option('mpedia_wacommerce_endpoint')) : ""); ?>" disabled />
                                        <small>Daftarkan endpoint ini saat add domain di <a href="#" target="_BLANK">Mutasi mpedia</a?< /small>
                                    </td>
                                </tr>
                                <tr>
                                    <td>API Key</td>
                                    <td><input type="text" name="mpedia_wacommerce_apikey_payment" value="<?php echo get_option('mpedia_wacommerce_apikey_payment'); ?>" />
                                        <small>Ambil api key di <a href="#" target="_BLANK">Mutasi mpedia</a?< /small>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Status</td>
                                    <td><select name="mpedia_wacommerce_status_payment">
                                            <option value="off" <?php echo ((get_option('mpedia_wacommerce_status_payment')) ? ((get_option('mpedia_wacommerce_status_payment') == "off") ? 'selected' : '') : ''); ?>>Tidak Aktif</option>
                                            <option value="on" <?php echo ((get_option('mpedia_wacommerce_status_payment')) ? ((get_option('mpedia_wacommerce_status_payment') == "on") ? 'selected' : '') : ''); ?>>Aktif</option>
                                        </select></td>
                                </tr>
                                <tr>
                                    <td>Pesan Notif User</td>
                                    <td>
                                        <textarea cols="50" rows="7" name="mpedia_wacommerce_payment_notif_user"><?php echo get_option('mpedia_wacommerce_payment_notif_user'); ?></textarea>
                                    </td>
                                    <td><span>Keyword tersedia :<br>
                                            {nama} Nama Pembeli<br>
                                            {order_id} Order ID<br>
                                            {jumlah} Jumlah Pembayaran<br>
                                        </span></td>
                                </tr>
                                <tr>
                                    <td>Pesan Notif Admin</td>
                                    <td>
                                        <textarea cols="50" rows="7" name="mpedia_wacommerce_payment_notif_admin"><?php echo get_option('mpedia_wacommerce_payment_notif_admin'); ?></textarea>
                                    </td>
                                    <td><span>Keyword tersedia :<br>
                                            {nama} Nama Pembeli<br>
                                            {order_id} Order ID<br>
                                            {jumlah} Jumlah Pembayaran<br>
                                        </span></td>
                                </tr>
                                <tr>
                                    <td colspan="2"><input type="submit" value="Simpan" /></td>
                                </tr>
                            </table>
                        </form>
                    </div>

                </div>
                <div style="clear:both"></div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

    <script id="rendered-js">
        $('.filter-show').on('click', function(event) {
            //The event won't be propagated to the document NODE and 
            // therefore events delegated to document won't be fired
            ///event.stopPropagation();
            $('.dropdown-menu-right').toggle();

            //checkboxes---------------------------------------------------
            $('.button-checkbox').each(function() {

                // Settings
                var $widget = $(this),
                    $button = $widget.find('button'),
                    $checkbox = $widget.find('input:checkbox'),
                    color = $button.data('color'),
                    settings = {
                        on: {
                            icon: 'glyphicon glyphicon-check'
                        },

                        off: {
                            icon: 'glyphicon glyphicon-unchecked'
                        }
                    };



                // Event Handlers
                $button.on('click', function() {
                    $checkbox.prop('checked', !$checkbox.is(':checked'));
                    $checkbox.triggerHandler('change');
                    updateDisplay();
                });
                $checkbox.on('change', function() {
                    updateDisplay();
                });

                // Actions
                function updateDisplay() {
                    var isChecked = $checkbox.is(':checked');

                    // Set the button's state
                    $button.data('state', isChecked ? "on" : "off");

                    // Set the button's icon
                    $button.find('.state-icon').
                    removeClass().
                    addClass('state-icon ' + settings[$button.data('state')].icon);

                    // Update the button's color
                    if (isChecked) {
                        $button.
                        removeClass('btn-default').
                        addClass('btn-' + color + ' active');
                    } else {
                        $button.
                        removeClass('btn-' + color + ' active').
                        addClass('btn-default');
                    }
                }

                // Initialization
                function init() {

                    updateDisplay();

                    // Inject the icon if applicable
                    if ($button.find('.state-icon').length == 0) {
                        $button.prepend('<i class="state-icon ' + settings[$button.data('state')].icon + '"></i>&nbsp;');
                    }
                }
                init();
            });
            //--------------------------checkbox over---------------------------------------
        });
        $(document).ready(function() {
            $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
                e.preventDefault();
                $(this).siblings('a.active').removeClass("active");
                $(this).addClass("active");
                var index = $(this).index();
                $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
                $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
            });
        });
        //-----------------------------------------------------------
        //# sourceURL=pen.js
    </script>
</body>

</html>