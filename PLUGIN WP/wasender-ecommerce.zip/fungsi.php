<?php
session_start();
date_default_timezone_set('Asia/Jakarta');


if (in_array(
    'woocommerce/woocommerce.php',
    apply_filters('active_plugins', get_option('active_plugins'))
)) {

    if (!function_exists('get_user_by')) {
        include(ABSPATH . "wp-includes/pluggable.php");
    }

    if (!function_exists('wp_generate_attachment_metadata')) {
        require_once(ABSPATH . "wp-admin" . '/includes/image.php');
        require_once(ABSPATH . "wp-admin" . '/includes/file.php');
        require_once(ABSPATH . "wp-admin" . '/includes/media.php');
    }

    define('mpedia_wacommerce_DIR_PATH', plugin_dir_path(__FILE__));

    /* CRON JOB */


    add_action('rest_api_init', function () {
        $endpoint   = get_option("mpedia_wacommerce_endpoint");
        $status_payment = get_option('mpedia_wacommerce_status_payment');

        register_rest_route('wacommerce', '/cronjob', array(
            'methods' => 'GET',
            'callback' => 'mpedia_wacommerce_cronjob',
        ));

        if ($status_payment == "on" and !empty(get_option("mpedia_wacommerce_apikey_payment"))) {
            register_rest_route('wacommerce', "/$endpoint", array(
                'methods' => 'GET',
                'callback' => function () {
                    return 200;
                },
            ));

            register_rest_route('wacommerce', "/$endpoint", array(
                'methods' => 'POST',
                'callback' => 'mpedia_wacommerce_auto_payment',
            ));
        }
    });

    function mpedia_wacommerce_auto_payment()
    {
        if (isset($_POST)) {
            $type           = ((isset($_POST['type'])) ? sanitize_text_field($_POST['type']) : null);
            $bank           = ((isset($_POST['bank'])) ? sanitize_text_field($_POST['bank']) : null);
            $norek          = ((isset($_POST['norek'])) ? sanitize_text_field($_POST['norek']) : null);
            $jumlah         = ((isset($_POST['jumlah'])) ? sanitize_text_field($_POST['jumlah']) : null);
            $keterangan     = ((isset($_POST['keterangan'])) ? sanitize_text_field($_POST['keterangan']) : null);
            $tanggal        = ((isset($_POST['tanggal'])) ? sanitize_text_field($_POST['tanggal']) : null);
            $apiKey         = ((isset($_POST['apikey'])) ? sanitize_text_field($_POST['apikey']) : null);

            $pesan_user     = get_option("mpedia_wacommerce_payment_notif_user");
            $pesan_admin    = get_option("mpedia_wacommerce_payment_notif_admin");

            if ($apikey != get_option("mpedia_wacommerce_apikey_payment")) {
                return false;
            }

            if ($type == "credit" and !empty($bank) and !empty($norek) and !empty($jumlah) and !empty($keterangan) and !empty($tanggal)) {
                global $wpdb;

                $get_order  = $wpdb->get_results("select * from " . $wpdb->prefix . "wc_order_stats as a inner join " . $wpdb->prefix . "wc_customer_lookup as b on a.customer_id = b.customer_id where a.status='wc-on-hold' and a.net_total = $jumlah limit 1 ");

                if (count($get_order) > 0) {
                    $order_id   = $get_order[0]->order_id;
                    $order      = new WC_Order($order_id);
                    $order->update_status('wc-processing');

                    $fullname   = $get_order[0]->first_name . (($get_order[0]->last_name != "") ? " " . $get_order[0]->last_name : "");
                    $formatJumlah = "Rp " . number_format($jumlah, 0, ',', '.');

                    $pesan_user     = str_replace("{nama}", $fullname, $pesan_user);
                    $pesan_user     = str_replace("{order_id}", $order_id, $pesan_user);
                    $pesan_user     = str_replace("{jumlah}", $formatJumlah, $pesan_user);

                    $pesan_admin     = str_replace("{nama}", $fullname, $pesan_admin);
                    $pesan_admin     = str_replace("{order_id}", $order_id, $pesan_admin);
                    $pesan_admin     = str_replace("{jumlah}", $formatJumlah, $pesan_admin);

                    $nomor_admin    = get_option('mpedia_wacommerce_nomer_admin');
                    $nomor_user     = get_post_meta($order_id, '_billing_whatsapp', true);

                    mpedia_wacommerce_send_message($nomor_user, $pesan_user);
                    mpedia_wacommerce_send_message($nomor_admin, $pesan_admin);

                    $pesan_proses   = get_option("mpedia_wacommerce_pesan_processing");
                    $pesan_proses   = str_replace("{nama}", $fullname, $pesan_proses);
                    $pesan_proses   = str_replace("{order_id}", $order_id, $pesan_proses);

                    mpedia_wacommerce_send_message($nomor_user, $pesan_proses);
                }
            }
        }
    }

    function mpedia_wacommerce_cronjob()
    {
        if (check_status_plugin('mpedia_wacommerce_status_cron_pending')) {
            global $wpdb;
            $orderan = $wpdb->get_results("select * from " . $wpdb->prefix . "wc_order_stats as a inner join " . $wpdb->prefix . "wc_customer_lookup as b on a.customer_id = b.customer_id where a.status='wc-on-hold'");

            foreach ($orderan as $data_order) {

                if (get_post_meta($data_order->order_id, 'mpedia_wacommerce_notif_h') == null) {
                    $order      = new WC_Order($data_order->order_id);
                    $order_created = date("m/d/Y", strtotime($data_order->date_created));
                    $sumday = strtotime("+" . ((int) get_option('mpedia_wacommerce_cron_pending')) . " days", strtotime($order_created));
                    $payment_method = $order->get_payment_method();
                    $key_pembayaran = array();
                    $produk = array();
                    foreach ($order->get_items() as $item) {
                        array_push($produk, $item->get_quantity() . "x " . $item->get_name() . "\nSubtotal :  Rp " . number_format($item->get_total(), 0, ',', '.'));
                    }
                    $key_orderan = implode("\n", $produk);

                    if ($payment_method == "bacs") {
                        $bacs_info  = get_option('woocommerce_bacs_accounts');

                        foreach ($bacs_info as $account) {
                            $account_name   = esc_attr(wp_unslash($account['account_name']));
                            $bank_name      = esc_attr(wp_unslash($account['bank_name']));
                            $account_number = esc_attr($account['account_number']);
                            $sort_code      = esc_attr($account['sort_code']);
                            $iban_code      = esc_attr($account['iban']);
                            $bic_code       = esc_attr($account['bic']);

                            if ($account_number != "" and $account_name != "") {
                                $data_pembayaran = $bank_name . "
" . $account_number . "
" . $account_name;
                                array_push($key_pembayaran, $data_pembayaran);
                            }
                        }
                    }

                    if ($sumday == strtotime(date("m/d/Y", time()))) {
                        $fullname = $data_order->first_name . (($data_order->last_name != "") ? " " . $data_order->last_name : "");
                        $total = number_format($data_order->net_total, 0, ',', '.');

                        if (get_option('mpedia_wacommerce_pesan_notif_blum_bayar') == "") {
                            $pesan = "Hallo " . $fullname . "\n\nPesanan kamu senilai : Rp " . $total . " Belum dibayarkan\n\nSilahkan lakukan pembayaran supaya pesanan dapat segera kami proses.\n\nTerima Kasih";
                        } else {
                            $pesan = get_option('mpedia_wacommerce_pesan_notif_blum_bayar');
                            $pesan  = str_replace("{detail}", $key_orderan, $pesan);
                            $pesan  = str_replace("{pembayaran}", implode("\n\n", $key_pembayaran), $pesan);
                            $pesan  = str_replace("{nama}", $fullname, $pesan);
                            $pesan  = str_replace("{order_id}", $data_order->order_id, $pesan);
                            $pesan  = str_replace("{total}", $total, $pesan);
                            $pesan  = str_replace("{tanggal}", $order_created, $pesan);
                        }

                        $wa = get_post_meta($data_order->order_id, '_billing_whatsapp', true);
                        if ($wa != null) {
                            mpedia_wacommerce_send_message($wa, $pesan);
                        }
                        add_post_meta($data_order->order_id, 'mpedia_wacommerce_notif_h', time());
                    }
                }
            }
        }
        return array('status' => true, 'message' => "Success");
    }


    function mpedia_wacommerce_menu()
    {
        add_menu_page('Wacommerce', 'Wacommerce', 'manage_options', 'mpedia-wacommerce', 'mpedia_wacommerce_menu_setting', 'dashicons-admin-generic');
    }

    function mpedia_wacommerce_menu_setting()
    {
        global $wpdb;
        $is_admin = current_user_can('manage_options');
        if ($is_admin) {

            if (empty(get_option("mpedia_wacommerce_endpoint"))) {
                update_option("mpedia_wacommerce_endpoint", rand());
            }

            mpedia_wacommerce_save_settings();
            mpedia_wacommerce_input_resi();
            mpedia_wacommerce_payment_setting();
            include(mpedia_wacommerce_DIR_PATH . 'pages/menu.php');
        }
    }

    function mpedia_wacommerce_admin_style()
    {
        $current_screen = get_current_screen();

        if (strpos($current_screen->base, 'mpedia-wacommerce') === false) {
            return;
        } else {
            wp_enqueue_style('admin-styles', plugins_url('assets/css/style.css', __FILE__));
        }
    }
    add_action('admin_enqueue_scripts', 'mpedia_wacommerce_admin_style');

    function mpedia_wacommerce_save_settings()
    {
        if (is_user_logged_in() and current_user_can('administrator') and (isset($_POST['mpedia_wacommerce_form_setting']) or isset($_POST['mpedia_wacommerce_setting_pesan']))) {
            foreach ($_POST as $key => $val) {
                if ($key == "mpedia_wacommerce_token_wa" and strpos($val, "*") === false) {
                    update_option($key, $val);
                } elseif ($key != "mpedia_wacommerce_token_wa") {
                    update_option($key, $val);
                }
            }
            mpedia_wacommerce_settings_notice();
        }
    }

    function mpedia_wacommerce_settings_notice($req = null)
    {
        echo '
	<div class="notice notice-success is-dismissible">
		<p>' . (($req == null) ? 'Save' : $req) . ' Success</p>
	</div>
	';
    }

    function mpedia_wacommerce_settings_notice_failed($error = null)
    {
        echo '
	<div class="notice notice-error is-dismissible">
		<p>' . $error . '</p>
	</div>';
    }

    function mpedia_wacommerce_payment_setting()
    {
        global $wpdb;
        if (is_user_logged_in() && current_user_can('administrator')) {
            if ($_POST and isset($_POST['mpedia_wacommerce_payment_setting'])) {

                $apikey         = sanitize_text_field($_POST['mpedia_wacommerce_apikey_payment']);
                $status         = sanitize_text_field($_POST['mpedia_wacommerce_status_payment']);
                $notifUser      = esc_attr($_POST['mpedia_wacommerce_payment_notif_user']);
                $notifAdmin     = esc_attr($_POST['mpedia_wacommerce_payment_notif_admin']);

                update_option("mpedia_wacommerce_apikey_payment", $apikey);
                update_option("mpedia_wacommerce_status_payment", $status);
                update_option("mpedia_wacommerce_payment_notif_user", $notifUser);
                update_option("mpedia_wacommerce_payment_notif_admin", $notifAdmin);

                return mpedia_wacommerce_settings_notice("Update");
            }
        }
    }

    function mpedia_wacommerce_input_resi()
    {
        global $wpdb;
        if (is_user_logged_in() && current_user_can('administrator')) {
            if ($_POST and isset($_POST['mpedia_wacommerce_input_resi'])) {

                $order_id   = sanitize_text_field($_POST['mpedia_wacommerce_orderan']);
                $resi   = sanitize_text_field($_POST['mpedia_wacommerce_nomer_resi']);

                if ($order_id != "" and $resi != "") {

                    $order      = new WC_Order($order_id);
                    $arr        = json_decode($order, true);
                    $error      = null;

                    if ($order->status != "") {
                        $cek = get_post_meta($order_id, 'mpedia_wacommerce_resi', true);
                        if (!$cek) {
                            $save = add_post_meta($order_id, 'mpedia_wacommerce_resi', $resi);
                            if ($save) {
                                $fullname  = $arr['billing']['first_name'] . (($arr['billing']['last_name'] != "") ? " " . $arr['billing']['last_name'] : "");
                                $wa = get_post_meta($order_id, '_billing_whatsapp', true);
                                $pesan = "Hallo $fullname\n\nPesanan kamu dengan Id Order $order_id sudah dikirim dengan nomer resi $resi\n\nMohon ditunggu sampai paket datang.\nTerima Kasih";
                                if (get_option('mpedia_wacommerce_pesan_kirim_resi') != "") {
                                    $pesan = get_option('mpedia_wacommerce_pesan_kirim_resi');
                                    $pesan = str_replace("{nama}", $fullname, $pesan);
                                    $pesan = str_replace("{order_id}", $order_id, $pesan);
                                    $pesan = str_replace("{resi}", $resi, $pesan);
                                }
                                $kirim = mpedia_wacommerce_send_message($wa, $pesan);
                            } else {
                                $error = "Proses Gagal";
                            }
                        } else {
                            $error = "Orderan ini sudah di input resi";
                        }
                    }
                } else {
                    $error = "Data tidak boleh kosong";
                }
                if ($error == null) {
                    mpedia_wacommerce_settings_notice("Request");
                } else {
                    mpedia_wacommerce_settings_notice_failed($error);
                }
            }
        }
    }

    function check_status_plugin($name = null)
    {
        $status_plugin = get_option('mpedia_wacommerce_status_plugin');
        $token = get_option('mpedia_wacommerce_token_wa');

        if ($name == null) {
            if ($status_plugin == "on" and $token != "") {
                return true;
            } else {
                return false;
            }
        } else {
            if ($status_plugin == "on" and $token != "" and get_option($name) != "") {
                return true;
            } else {
                return false;
            }
        }
    }


    /*--- HANDLE POST KONFIRMASI ---*/
    add_action('wp_head', 'proses_form_konfirmasi');

    function proses_form_konfirmasi()
    {
        global $woocommerce, $order, $post, $wpdb;

        if ($_POST and isset($_POST['mpedia_wacommerce_form_konfirmasi_order']) and isset($_FILES['file']['tmp_name']) and $_FILES['file']['name'] != '') {

            $order_id   = sanitize_text_field($_POST['mpedia_wacommerce_konfirmasi_order_id']);
            $bank_tujuan   = sanitize_text_field($_POST['mpedia_wacommerce_konfirmasi_bank_tujuan']);
            $nama_pengirim   = sanitize_text_field($_POST['mpedia_wacommerce_konfirmasi_nama_pengirim']);
            $rek_pengirim   = sanitize_text_field($_POST['mpedia_wacommerce_konfirmasi_rek_pengirim']);

            $cari   = $wpdb->get_results("select * from " . $wpdb->prefix . "wc_order_stats where order_id=$order_id limit 1");

            if (count($cari) > 0) {
                $order      = new WC_Order($order_id);
                $parse      = json_decode($order, true);
                if (!$order and $parse['status'] != "") {
                    echo "<script>alert('Order ID tidak ditemukan');</script>";
                } else {
                    $cek = wc_get_order_item_meta($order_id, 'mpedia_wacommerce_konfirmasi_transfer', true);
                    if (!empty($cek)) {
                        echo "<script>alert('Order id sudah pernah dikonfirmasi');</script>";
                    } else {
                        $bukti_transfer = $_FILES['file'];
                        $allowed_file_types = array('jpg' => 'image/jpg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'png' => 'image/png');
                        $overrides = array('test_form' => false, 'mimes' => $allowed_file_types);
                        $movefile = wp_handle_upload($bukti_transfer, $overrides);
                        $imageurl = "";
                        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

                        if ($movefile && !isset($movefile['error'])) {
                            $imageurl = $movefile['url'];
                            $data_update = json_encode(array('bank_tujuan' => $bank_tujuan, 'nama_pengirim' => $nama_pengirim, 'rek_pengirim' => $rek_pengirim));
                            wc_update_order_item_meta($order_id, 'mpedia_wacommerce_konfirmasi_transfer', $data_update);
                            mpedia_wacommerce_send_message(get_option('mpedia_wacommerce_nomer_admin'), "Konfirmasi Transfer\n\nOrder Id : $order_id\nRek Tujuan : $bank_tujuan\nPengirim : $nama_pengirim\nRek Pengirim : $rek_pengirim\nUrl Image : $imageurl\n\nTerima Kasih");
                            echo "<script>alert('Upload Sukses, Terima Kasih');</script>";
                        } else {
                            echo "<script>alert('Upload Gagal, " . $movefile['error'] . "');</script>";
                        }
                    }
                }
            } else {
                echo "<script>alert('Order ID tidak ditemukan');</script>";
            }

            echo "<script>window.location.href='" . $actual_link . "';</script>";
            exit;
        }
    }

    add_filter('after_setup_theme', 'mpedia_wacommerce_pages_konfirmasi');

    function mpedia_wacommerce_pages_konfirmasi()
    {

        $bacs_info  = get_option('woocommerce_bacs_accounts');
        if ($bacs_info) {
            $list_bank = array();
            foreach ($bacs_info as $account) {
                $account_name   = esc_attr(wp_unslash($account['account_name']));
                $bank_name      = esc_attr(wp_unslash($account['bank_name']));
                $account_number = esc_attr($account['account_number']);
                $sort_code      = esc_attr($account['sort_code']);
                $iban_code      = esc_attr($account['iban']);
                $bic_code       = esc_attr($account['bic']);

                array_push($list_bank, '<option value="' . $bank_name . '_' . $account_number . '">' . $bank_name . ' - ' . $account_number . ' (' . $account_name . ')</option>');
            }
        }

        $page = get_page_by_title('Konfirmasi Order');

        if ($page->ID == "" or $page->post_status != "publish") {
            // Create post object
            $my_post = array(
                'post_type'     => "page",
                'post_title'    => "Konfirmasi Order",
                'post_content'  => '<div class="container" style="width:100%; margin-top:50px; margin-bottom: 50px;">
            <p class="respon" id="respon"></p>
            <form enctype="multipart/form-data" method="POST" action="" name="mpedia_wacommerce_konfirmasi_form" id="mpedia_wacommerce_konfirmasi_form">
            <input type="hidden" class="form-control" id="mpedia_wacommerce_form_konfirmasi_order" name="mpedia_wacommerce_form_konfirmasi_order">
                <div id="inputan-form">
                    <div class="form-group">
                        <label for="input-nama">Order Id</label>
                        <input type="text" name="mpedia_wacommerce_konfirmasi_order_id" class="form-control" id="mpedia_wacommerce_konfirmasi_order_id" placeholder="214" required>
                    </div>
                </div>
                <div id="inputan-form">
                    <div class="form-group">
                        <label for="input-nama">Bank Transfer</label>
                        <select name="mpedia_wacommerce_konfirmasi_bank_tujuan">' . implode("", $list_bank) . '</select>
                    </div>
                </div>
                <div id="inputan-form">
                    <div class="form-group">
                        <label for="input-nama">Nama Pengirim</label>
                        <input type="text" name="mpedia_wacommerce_konfirmasi_nama_pengirim" class="form-control" id="mpedia_wacommerce_konfirmasi_nama_pengirim" placeholder="Budi Santoso" required>
                    </div>
                </div>
                <div id="inputan-form">
                    <div class="form-group">
                        <label for="input-nama">Nomer Rek Pengirim</label>
                        <input type="text" name="mpedia_wacommerce_konfirmasi_rek_pengirim" class="form-control" id="mpedia_wacommerce_konfirmasi_rek_pengirim" placeholder="4060302012" required>
                    </div>
                </div>
                <div id="inputan-form">
                    <div class="form-group">
                        <label for="input-nama">Bukti Transfer</label>
                        <input type="file" name="file" id="file"/>
                    </div>
                </div>
                <input type="submit" name="mpedia_wacommerce_konfirmasi_submit" id="mpedia_wacommerce_konfirmasi_submit" value="Submit">
            </form>
        </div>',
                'post_status'   => 'publish',
                'post_author'   => 1
            );
            // Insert the post into the database
            wp_insert_post($my_post);
        }
    }




    add_action('admin_notices', 'mpedia_wacommerce_notice_token');

    function mpedia_wacommerce_notice_token()
    {
        $is_admin = current_user_can('manage_options');
        if (is_user_logged_in() && current_user_can('administrator')) {
            if ($is_admin) {
                $class = 'notice notice-error';
                $message = '';
                if (false === get_option('mpedia_wacommerce_token_wa')) {
                    $message = sprintf(__('wacommerce fresh install, please setup and add your mpedia token'));
                } else if ('' == get_option('mpedia_wacommerce_token_wa')) {
                    $message = sprintf(__('wacommerce token missing, please add your mpedia token'));
                }
                if ($message)
                    printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), $message);
            }
        }
    }

    add_action('woocommerce_order_status_changed', 'mpedia_wacommerce_change_status_order', 99, 3);

    function mpedia_wacommerce_change_status_order($order_id, $old_status, $new_status)
    {
        $is_admin = current_user_can('manage_options');
        if (is_user_logged_in() && current_user_can('administrator')) {
            if ($is_admin) {
                $order      = new WC_Order($order_id);
                $arr        = json_decode($order, true);
                $wa         = null;

                $nama   = $arr['billing']['first_name'] . " " . $arr['billing']['last_name'];

                foreach ($arr['meta_data'] as $meta) {
                    if ($meta['key'] == "_billing_whatsapp") {
                        $wa = $meta['value'];
                    }
                }

                if (!empty($wa)) {

                    //status : completed, processing, pending, on-hold, cancelled, refunded, failed
                    if ($new_status == "completed") {
                        $pesan  = get_option("mpedia_wacommerce_pesan_completed");
                    } elseif ($new_status == "processing") {
                        $pesan  = get_option("mpedia_wacommerce_pesan_processing");
                    } elseif ($new_status == "pending") {
                        $pesan  = get_option("mpedia_wacommerce_pesan_pending");
                    } elseif ($new_status == "cancelled") {
                        $pesan  = get_option("mpedia_wacommerce_pesan_cancelled");
                    } elseif ($new_status == "refunded") {
                        $pesan  = get_option("mpedia_wacommerce_pesan_refunded");
                    } elseif ($new_status == "failed") {
                        $pesan  = get_option("mpedia_wacommerce_pesan_failed");
                    } else {
                        return;
                    }

                    $pesan  = str_replace("{nama}", $nama, $pesan);
                    $pesan  = str_replace("{order_id}", $order_id, $pesan);

                    mpedia_wacommerce_send_message($wa, $pesan);
                }
            }
        }
    }


    // Add a custom fee based o cart subtotal
    add_action('woocommerce_cart_calculate_fees', 'mpedia_wacommerce_custom_fee_for_tinkoff', 20, 1);
    function mpedia_wacommerce_custom_fee_for_tinkoff($cart)
    {
        global $wpdb;

        if (is_admin() && !defined('DOING_AJAX'))
            return;

        if (!(is_checkout() && !is_wc_endpoint_url()))
            return; // Only checkout page

        $payment_method = WC()->session->get('chosen_payment_method');

        if ('bacs' == $payment_method) {
            $loop = true;
            while ($loop) {
                $surcharge = rand(000, 999);
                $cart->add_fee('Code', $surcharge, true);
                $total = $cart->subtotal + $surcharge;
                $cek = $wpdb->get_results("select * from " . $wpdb->prefix . "wc_order_stats where status='wc-on-hold' and net_total = $total ");
                if (count($cek) == 0) {
                    $loop = false;
                }
            }
        }
    }

    // jQuery - Update checkout on methode payment change  
    add_action('wp_footer', 'mpedia_wacommerce_custom_checkout_jqscript');
    function mpedia_wacommerce_custom_checkout_jqscript()
    {
        if (!(is_checkout() && !is_wc_endpoint_url()))
            return; // Only checkout page
?>
        <script type="text/javascript">
            jQuery(function($) {
                $('form.checkout').on('change', 'input[name="payment_method"]', function() {
                    $(document.body).trigger('update_checkout');
                });
            });
        </script>
<?php
    }


    add_action('woocommerce_thankyou_order_id', 'mpedia_wacommerce_proses_notif');

    function mpedia_wacommerce_proses_notif($order_id)
    {

        if (check_status_plugin('mpedia_wacommerce_status_notif_order')) {
            global $woocommerce, $order, $post;

            if ($order_id != "" and check_status_plugin('mpedia_wacommerce_status_plugin') and get_post_meta($order_id, 'mpedia_wacommerce_notif_order', true) == null) {

                $order      = new WC_Order($order_id);
                $currency      = $order->get_currency();
                $payment_method = $order->get_payment_method();
                $payment_title = $order->get_payment_method_title();
                $order_created  = $order->get_date_created()->date('d-m-Y H:i:s');
                $total      = $order->total;

                foreach ($order->get_items() as $item) {
                    $produk[] = $item->get_quantity() . "x " . $item->get_name() . "\nSubtotal :  Rp " . number_format($item->get_total(), 0, ',', '.');
                }

                $key_orderan = implode("\n", $produk);

                $key_pembayaran = array();

                if ($payment_method == "bacs") {
                    $bacs_info  = get_option('woocommerce_bacs_accounts');

                    foreach ($bacs_info as $account) {
                        $account_name   = esc_attr(wp_unslash($account['account_name']));
                        $bank_name      = esc_attr(wp_unslash($account['bank_name']));
                        $account_number = esc_attr($account['account_number']);
                        $sort_code      = esc_attr($account['sort_code']);
                        $iban_code      = esc_attr($account['iban']);
                        $bic_code       = esc_attr($account['bic']);

                        if ($account_number != "" and $account_name != "") {
                            $data_pembayaran = $bank_name . "
" . $account_number . "
" . $account_name;
                            array_push($key_pembayaran, $data_pembayaran);
                        }
                    }
                }
                $arr        = json_decode($order, true);
                $first_name = $arr['billing']['first_name'];
                $last_name  = " " . $arr['billing']['last_name'];
                $full_name  = $first_name . $last_name;
                $wa         = null;

                foreach ($arr['meta_data'] as $meta) {
                    if ($meta['key'] == "_billing_whatsapp") {
                        $wa = $meta['value'];
                    }
                }

                if ($wa != null or $wa != "") {

                    if (get_option('mpedia_wacommerce_pesan_order') == "") {
                        $pesan  = "Hallo $full_name

Pesanan kamu sudah kami terima, silahkan lakukan pembayaran supaya pesanan kamu dapat kita kirim.

Terima Kasih.";
                    } else {
                        $pesan  = get_option('mpedia_wacommerce_pesan_order');
                        $pesan  = str_replace("{detail}", $key_orderan, $pesan);
                        $pesan  = str_replace("{pembayaran}", implode("\n\n", $key_pembayaran), $pesan);
                        $pesan  = str_replace("{nama}", $full_name, $pesan);
                        $pesan  = str_replace("{order_id}", $order_id, $pesan);
                        $pesan  = str_replace("{total}", number_format($total, 0, ',', '.'), $pesan);
                        $pesan  = str_replace("{tanggal}", $order_created, $pesan);
                        $pesan  = str_replace("{payment}", $payment_title, $pesan);
                    }

                    mpedia_wacommerce_send_message($wa, $pesan);
                    $_SESSION['notif'] = true;
                    add_post_meta($order_id, 'mpedia_wacommerce_notif_order', true);
                }
            }
        }
        return true;
    }

    function mpedia_wacommerce_send_message($wa, $pesan, $delay = 0, $schedule = 0)
    {
        $token  = get_option("mpedia_wacommerce_token_wa");
        $url = get_option("mpedia_wacommerce_link");
        if (!$token) {
            return false;
        }
        $data = [
            'api_key' => $token,
            'number'  => $wa,
            'message' => $pesan
        ];

        $curl = curl_init();
        curl_setopt_array(
            $curl,
            array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => json_encode($data)
            )
        );

        $response = curl_exec($curl);

        return $response;
    }


    add_filter('woocommerce_billing_fields', 'custom_woocommerce_billing_fields');

    function custom_woocommerce_billing_fields($fields)
    {
        $_SESSION['notif']  = false;

        $fields['billing_whatsapp'] = array(
            'label' => __('Whatsapp Number', 'woocommerce'), // Add custom field label
            'placeholder' => _x('628123456', 'placeholder', 'woocommerce'), // Add custom field placeholder
            'required' => true, // if field is required or not
            'clear' => false, // add clear or not
            'type' => 'number', // add field type
            'class' => array('my-css')    // add class name
        );

        return $fields;
    }
}
?>